package com.xenon.addon.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import static com.xenon.addon.XenonAddon.LOG;

public class AmethystESP extends Module {

    // ── Settings ────────────────────────────────────────────────────────────
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender  = settings.createGroup("Render");
    private final SettingGroup sgAlert   = settings.createGroup("Alert");

    private final Setting<Integer> simDistance = sgGeneral.add(
            new IntSetting.Builder()
                    .name("sim-distance")
                    .description("Chunk scan radius around the player.")
                    .defaultValue(8).min(1).sliderMax(32)
                    .build()
    );

    private final Setting<Integer> clusterThreshold = sgGeneral.add(
            new IntSetting.Builder()
                    .name("min-cluster-size")
                    .description("Minimum amethyst hits per chunk to mark it.")
                    .defaultValue(3).min(1).sliderMax(20)
                    .build()
    );

    private final Setting<Double> chunkY = sgGeneral.add(
            new DoubleSetting.Builder()
                    .name("chunk-y-level")
                    .description("Y level at which the flat chunk overlay is drawn.")
                    .defaultValue(55).min(-64).max(320)
                    .build()
    );

    private final Setting<Boolean> esp = sgRender.add(
            new BoolSetting.Builder()
                    .name("block-esp")
                    .description("Draw a box around each amethyst block.")
                    .defaultValue(true)
                    .build()
    );

    private final Setting<Boolean> chunkMark = sgRender.add(
            new BoolSetting.Builder()
                    .name("chunk-mark")
                    .description("Draw a flat slab over the whole chunk.")
                    .defaultValue(true)
                    .build()
    );

    private final Setting<Boolean> tracers = sgRender.add(
            new BoolSetting.Builder()
                    .name("tracers")
                    .description("Draw a tracer line to the nearest amethyst per chunk.")
                    .defaultValue(true)
                    .build()
    );

    private final Setting<SettingColor> espColor = sgRender.add(
            new ColorSetting.Builder()
                    .name("esp-color")
                    .description("Color for block ESP and tracers.")
                    .defaultValue(new SettingColor(180, 100, 255, 180))
                    .build()
    );

    private final Setting<SettingColor> chunkColor = sgRender.add(
            new ColorSetting.Builder()
                    .name("chunk-color")
                    .description("Color for the chunk slab overlay.")
                    .defaultValue(new SettingColor(180, 100, 255, 80))
                    .build()
    );

    private final Setting<Boolean> chatNotify = sgAlert.add(
            new BoolSetting.Builder()
                    .name("chat-alert")
                    .description("Send a chat message when a new geode chunk is found.")
                    .defaultValue(true)
                    .build()
    );

    // ── State ────────────────────────────────────────────────────────────────
    private final Map<ChunkPos, Set<BlockPos>> foundClusters = new ConcurrentHashMap<>();
    private final Set<ChunkPos> notifiedChunks = ConcurrentHashMap.newKeySet();
    private int tickCounter = 0;

    private static final double CHUNK_THICKNESS = 0.05;

    public AmethystESP() {
        super(com.xenon.addon.XenonAddon.CATEGORY, "amethyst-esp",
                "Highlights amethyst geodes in loaded chunks.");
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────
    @Override
    public void onActivate() {
        foundClusters.clear();
        notifiedChunks.clear();
        fullScan();
    }

    @Override
    public void onDeactivate() {
        foundClusters.clear();
        notifiedChunks.clear();
    }

    // ── Events ───────────────────────────────────────────────────────────────
    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.world == null || mc.player == null) return;
        if (++tickCounter % 40 != 0) return;

        ChunkPos center = mc.player.getChunkPos();
        int r = simDistance.get();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                WorldChunk chunk = mc.world.getChunkManager()
                        .getWorldChunk(center.x + dx, center.z + dz, false);
                if (chunk != null) scanChunk(chunk);
            }
        }
    }

    @EventHandler
    private void onChunkData(ChunkDataEvent event) {
        scanChunk(event.chunk());
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (mc.world == null || mc.player == null || foundClusters.isEmpty()) return;

        double fixedY = chunkY.get();

        for (Map.Entry<ChunkPos, Set<BlockPos>> entry : foundClusters.entrySet()) {
            ChunkPos cp = entry.getKey();
            Set<BlockPos> positions = entry.getValue();
            if (positions.isEmpty()) continue;

            // Chunk slab
            if (chunkMark.get()) {
                double x1 = cp.getStartX();
                double z1 = cp.getStartZ();
                double x2 = cp.getEndX() + 1;
                double z2 = cp.getEndZ() + 1;
                event.renderer.box(x1, fixedY, z1, x2, fixedY + CHUNK_THICKNESS, z2,
                        chunkColor.get(), chunkColor.get(), ShapeMode.Both, 0);
            }

            // Block ESP
            if (esp.get()) {
                for (BlockPos p : positions) {
                    event.renderer.box(p.getX(), p.getY(), p.getZ(),
                            p.getX() + 1, p.getY() + 1, p.getZ() + 1,
                            espColor.get(), espColor.get(), ShapeMode.Both, 0);
                }
            }

            // Tracers — line to nearest block in each chunk
            if (tracers.get()) {
                BlockPos nearest = null;
                double nearestDist = Double.MAX_VALUE;
                for (BlockPos p : positions) {
                    double d = p.getSquaredDistance(mc.player.getBlockPos());
                    if (d < nearestDist) { nearestDist = d; nearest = p; }
                }
                if (nearest != null) {
                    Vec3d start = mc.player.getEyePos();
                    Vec3d end   = Vec3d.ofCenter(nearest);
                    event.renderer.line(start.x, start.y, start.z,
                            end.x, end.y, end.z, espColor.get());
                }
            }
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────
    private void fullScan() {
        if (mc.world == null || mc.player == null) return;
        ChunkPos center = mc.player.getChunkPos();
        int r = simDistance.get();
        int scanned = 0;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                WorldChunk chunk = mc.world.getChunkManager()
                        .getWorldChunk(center.x + dx, center.z + dz, false);
                if (chunk != null) { scanChunk(chunk); scanned++; }
            }
        }
        info("Scanned §7" + scanned + "§r chunks | §d" + foundClusters.size() + "§r geodes found");
    }

    private void scanChunk(WorldChunk chunk) {
        if (mc.world == null) return;
        ChunkPos cp = chunk.getPos();
        Set<BlockPos> hits = new HashSet<>();
        int baseX = cp.x << 4;
        int baseZ = cp.z << 4;

        for (int y = -64; y <= 70; y++) {
            for (int lx = 0; lx < 16; lx++) {
                for (int lz = 0; lz < 16; lz++) {
                    BlockPos pos = new BlockPos(baseX + lx, y, baseZ + lz);
                    if (isAmethystNearby(pos)) {
                        hits.add(pos.toImmutable());
                    }
                }
            }
        }

        if (hits.size() >= clusterThreshold.get()) {
            foundClusters.put(cp, hits);
            if (chatNotify.get() && notifiedChunks.add(cp)) {
                info("Amethyst at chunk §d" + cp.x + ", " + cp.z
                        + " §7(" + hits.size() + " hits)");
            }
        } else {
            foundClusters.remove(cp);
            notifiedChunks.remove(cp);
        }
    }

    private boolean isAmethystNearby(BlockPos pos) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    BlockState state = mc.world.getBlockState(pos.add(dx, dy, dz));
                    if (state.isOf(Blocks.AMETHYST_CLUSTER)
                            || state.isOf(Blocks.LARGE_AMETHYST_BUD)
                            || state.isOf(Blocks.MEDIUM_AMETHYST_BUD)
                            || state.isOf(Blocks.SMALL_AMETHYST_BUD)
                            || state.isOf(Blocks.BUDDING_AMETHYST)
                            || state.isOf(Blocks.AMETHYST_BLOCK)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
