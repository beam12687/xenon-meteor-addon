package com.xenon.addon.modules;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ActivityDebug extends Module {

    // ── Settings ─────────────────────────────────────────────────────────────
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> yLevel = sgGeneral.add(
            new DoubleSetting.Builder()
                    .name("y-level")
                    .description("Only flag block activity at or below this Y level.")
                    .defaultValue(16).min(-64).max(320)
                    .build()
    );

    private final Setting<Boolean> notification = sgGeneral.add(
            new BoolSetting.Builder()
                    .name("notification")
                    .description("Show an on-screen notification when a new suspicious chunk is found.")
                    .defaultValue(false)
                    .build()
    );

    private final Setting<SettingColor> markerColor = sgGeneral.add(
            new ColorSetting.Builder()
                    .name("marker-color")
                    .description("Color of the chunk slab overlay.")
                    .defaultValue(new SettingColor(255, 220, 0, 80))
                    .build()
    );

    // ── State ─────────────────────────────────────────────────────────────────
    private static final long   NOTIFY_COOLDOWN_MS       = 1250L;
    private static final double MARKER_SURFACE_Y         = 57.0;
    private static final double MARKER_SURFACE_THICKNESS = 0.05;

    private final Set<ChunkPos>              susChunks      = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Map<Long, Long>            lastNotifiedAt = new ConcurrentHashMap<>();
    private final Map<Class<?>, List<Field>> blockPosFields = new ConcurrentHashMap<>();
    private final Map<Class<?>, List<Field>> vec3Fields     = new ConcurrentHashMap<>();
    private final Map<Class<?>, List<Field>> doubleFields   = new ConcurrentHashMap<>();
    private final Map<Class<?>, List<Field>> nestedFields   = new ConcurrentHashMap<>();
    private final ThreadLocal<Set<Integer>>  exploredObjects =
            ThreadLocal.withInitial(() -> Collections.newSetFromMap(new ConcurrentHashMap<>()));

    public ActivityDebug() {
        super(com.xenon.addon.XenonAddon.CATEGORY, "activity-debug",
                "Detects underground block/packet activity and marks those chunks.");
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    @Override
    public void onDeactivate() {
        susChunks.clear();
        lastNotifiedAt.clear();
        blockPosFields.clear();
        vec3Fields.clear();
        doubleFields.clear();
        nestedFields.clear();
    }

    // ── Events ────────────────────────────────────────────────────────────────
    @EventHandler
    private void onPacketReceive(PacketEvent.Receive event) {
        Packet<?> packet = event.packet;

        if (packet instanceof ChunkDeltaUpdateS2CPacket sectionUpdate) {
            sectionUpdate.visitUpdates((pos, state) ->
                    checkAndAdd(pos.getX(), pos.getY(), pos.getZ()));
            return;
        }

        if (packet instanceof BlockUpdateS2CPacket blockUpdate) {
            BlockPos pos = blockUpdate.getPos();
            checkAndAdd(pos.getX(), pos.getY(), pos.getZ());
            return;
        }

        // Deep-reflect other packets for any hidden coordinates
        exploredObjects.get().clear();
        analyzeObject(packet, 0);
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (mc.world == null) return;

        double markerBaseY = Math.max(mc.world.getBottomY(),
                Math.min(MARKER_SURFACE_Y, mc.world.getTopY()));

        for (ChunkPos cp : susChunks) {
            double x1 = cp.getStartX();
            double z1 = cp.getStartZ();
            double x2 = cp.getEndX() + 1;
            double z2 = cp.getEndZ() + 1;
            double y1 = markerBaseY;
            double y2 = y1 + MARKER_SURFACE_THICKNESS;

            event.renderer.box(x1, y1, z1, x2, y2, z2,
                    markerColor.get(), markerColor.get(), ShapeMode.Both, 0);
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private void checkAndAdd(double x, double y, double z) {
        if (mc.player != null && mc.player.getY() < 0.0) return;
        if (y <= yLevel.get()) {
            ChunkPos cp = new ChunkPos((int) Math.floor(x) >> 4, (int) Math.floor(z) >> 4);
            if (susChunks.add(cp)) {
                maybeNotify(cp, y);
            }
        }
    }

    private void maybeNotify(ChunkPos cp, double y) {
        if (!notification.get() || mc.player == null || mc.world == null) return;

        long key = cp.toLong();
        long now  = System.currentTimeMillis();
        if (now - lastNotifiedAt.getOrDefault(key, 0L) < NOTIFY_COOLDOWN_MS) return;

        lastNotifiedAt.put(key, now);
        info("Activity detected at chunk §e" + cp.x + ", " + cp.z
                + " §7Y " + (int) Math.floor(y));
    }

    // ── Reflection packet analysis ────────────────────────────────────────────
    private void analyzeObject(Object obj, int depth) {
        if (obj == null || depth > 3) return;
        int hash = System.identityHashCode(obj);
        if (!exploredObjects.get().add(hash)) return;

        Class<?> clazz = obj.getClass();

        blockPosFields.computeIfAbsent(clazz, c -> getFieldsOfType(c, BlockPos.class));
        vec3Fields    .computeIfAbsent(clazz, c -> getFieldsOfType(c, Vec3d.class));
        doubleFields  .computeIfAbsent(clazz, c -> getFieldsOfType(c, double.class));
        nestedFields  .computeIfAbsent(clazz, c -> {
            List<Field> list = new ArrayList<>();
            while (c != null && c != Object.class) {
                for (Field f : c.getDeclaredFields()) {
                    if (!Modifier.isStatic(f.getModifiers())
                            && !f.getType().isPrimitive()
                            && !f.getType().getName().startsWith("java.")
                            && !f.getType().isEnum()) {
                        f.setAccessible(true);
                        list.add(f);
                    }
                }
                c = c.getSuperclass();
            }
            return list;
        });

        for (Field f : blockPosFields.get(clazz)) {
            try {
                BlockPos bp = (BlockPos) f.get(obj);
                if (bp != null) checkAndAdd(bp.getX(), bp.getY(), bp.getZ());
            } catch (Exception ignored) {}
        }

        for (Field f : vec3Fields.get(clazz)) {
            try {
                Vec3d v = (Vec3d) f.get(obj);
                if (v != null) checkAndAdd(v.x, v.y, v.z);
            } catch (Exception ignored) {}
        }

        List<Field> dFields = doubleFields.get(clazz);
        if (dFields.size() >= 3) {
            try {
                double x = dFields.get(0).getDouble(obj);
                double y = dFields.get(1).getDouble(obj);
                double z = dFields.get(2).getDouble(obj);
                if (Math.abs(x) < 3.0E7 && Math.abs(z) < 3.0E7 && y > -2048 && y < 2048) {
                    checkAndAdd(x, y, z);
                }
            } catch (Exception ignored) {}
        }

        for (Field f : nestedFields.get(clazz)) {
            try {
                Object nested = f.get(obj);
                if (nested != null) analyzeObject(nested, depth + 1);
            } catch (Exception ignored) {}
        }
    }

    private List<Field> getFieldsOfType(Class<?> clazz, Class<?> type) {
        List<Field> list = new ArrayList<>();
        while (clazz != null && clazz != Object.class) {
            for (Field f : clazz.getDeclaredFields()) {
                if (!Modifier.isStatic(f.getModifiers()) && f.getType() == type) {
                    f.setAccessible(true);
                    list.add(f);
                }
            }
            clazz = clazz.getSuperclass();
        }
        return list;
    }
}
